from shiny import App, ui, reactive, render
import pandas as pd
import matplotlib.pyplot as plt
import seaborn as sns
import numpy as np

# Define the UI for the app
app_ui = ui.page_fluid(
    ui.layout_sidebar(
        ui.panel_sidebar(
            ui.input_slider("year_range", "Select Year Range", min=1940, max=2020, value=(2005, 2015))
        ),
        ui.panel_main(
            ui.output_plot("trend_plot")
        )
    )
)

# Define server logic required to draw plots
def server(input, output, session):
    # Specify the path to your CSV file
    csv_file_path = 'all_yearly.csv'  # Make sure this path is correct
    data = reactive.Value(pd.read_csv(csv_file_path))  # Load data once at app start

    @output
    @render.plot
    def trend_plot():
        df = data.get()
        if df is not None:
            # Filter data based on the UI input year range
            filtered_df = df[(df['year'] >= input.year_range()[0]) & (df['year'] <= input.year_range()[1])]
            
            # Generate plot for the filtered dataset
            plt.figure()
            ax = sns.lineplot(data=filtered_df, x='year', y='PRCPTOT', ci=None)  # Main blue line without confidence interval
            sns.regplot(x='year', y='PRCPTOT', data=filtered_df, scatter=False, ci=None,
                        color='red', line_kws={"linestyle": "--"}, ax=ax)  # Red dotted trend line without CI
            
            plt.title('Trend Over Time: PRCPTOT')
            plt.xlabel('Year')
            plt.ylabel('PRCPTOT')
            return plt.gcf()

app = App(app_ui, server)
